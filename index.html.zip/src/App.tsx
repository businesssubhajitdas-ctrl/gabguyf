/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle2, 
  Star, 
  Clock, 
  ShieldCheck, 
  MapPin, 
  Menu, 
  X,
  ChevronRight,
  Sparkles,
  Heart,
  Scissors,
  Palette,
  Droplets,
  Hand
} from 'lucide-react';

// --- Types ---
interface Service {
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}

interface GalleryItem {
  id: number;
  url: string;
  category: string;
}

// --- Constants ---
const CONTACT_NUMBER = "+91 8446471210";
const WHATSAPP_LINK = "https://api.whatsapp.com/send?phone=918446471210&text=Hi,%20I'm%20interested%20in%20booking%20a%20nail%20service.";
const CALL_LINK = `tel:+918446471210`;

const SERVICES: Service[] = [
  { 
    title: "Acrylic Nails", 
    description: "Durable and stunning extensions for a perfect look.",
    icon: <Sparkles className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Eyelash Extensions", 
    description: "Enhance your eyes with premium lash services.",
    icon: <Star className="w-6 h-6" />,
    image: "https://images.pexels.com/photos/33637609/pexels-photo-33637609.jpeg"
  },
  { 
    title: "Gel Manicures", 
    description: "Long-lasting shine and chip-resistant color.",
    icon: <Droplets className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Hand & Foot Massages", 
    description: "Relaxing spa experience in the comfort of your home.",
    icon: <Hand className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1519415387722-a1c3bbef716c?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Nail Art", 
    description: "Creative and intricate designs customized for you.",
    icon: <Palette className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1607779097040-26e80aa78e66?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Nail Extensions", 
    description: "Beautifully crafted extensions for elegant hands.",
    icon: <ChevronRight className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Nail Repair", 
    description: "Quick fixes for broken or damaged nails.",
    icon: <ShieldCheck className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=800&auto=format&fit=crop"
  },
  { 
    title: "Polish Removal", 
    description: "Safe and gentle removal of old polish or gel.",
    icon: <X className="w-6 h-6" />,
    image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?q=80&w=800&auto=format&fit=crop"
  }
];

const GALLERY: GalleryItem[] = [
  { id: 1, url: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=800", category: "Nail Art" },
  { id: 2, url: "https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=800", category: "Gel Polish" },
  { id: 3, url: "https://images.unsplash.com/photo-1607779097040-26e80aa78e66?q=80&w=800", category: "Extensions" },
  { id: 4, url: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=800", category: "Bridal" },
  { id: 5, url: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=800", category: "Minimalist" },
  { id: 6, url: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?q=80&w=800", category: "Luxury" },
];

const REASONS = [
  { title: "Professional Artists", desc: "Highly skilled and experienced nail technicians.", icon: <Star className="text-pink-500" /> },
  { title: "Hygienic Tools", desc: "Strict sterilization and single-use disposables.", icon: <ShieldCheck className="text-pink-500" /> },
  { title: "Home Service", desc: "Convenient service across all areas of Kolkata.", icon: <MapPin className="text-pink-500" /> },
  { title: "Affordable Prices", desc: "Premium quality services at competitive rates.", icon: <Heart className="text-pink-500" /> },
  { title: "Premium Products", desc: "We use only top-tier international brands.", icon: <Sparkles className="text-pink-500" /> },
];

// --- Components ---

const NailIcon = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 10h6V6a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4Z" />
    <path d="M7 10h10a2 2 0 0 1 2 2v7a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3v-7a2 2 0 0 1 2-2Z" />
    <path d="M12 14v4" />
  </svg>
);

const Logo = ({ className = "", dark = false }: { className?: string, dark?: boolean }) => (
  <div className={`flex items-center gap-3 ${className}`}>
    <motion.div
      whileHover={{ scale: 1.1, rotate: 5 }}
      className="relative flex items-center justify-center w-10 h-10"
    >
      <div className={`absolute inset-0 rounded-xl blur-md opacity-40 ${dark ? 'bg-pink-400' : 'bg-pink-300'}`} />
      <div className={`relative z-10 w-full h-full rounded-xl flex items-center justify-center shadow-lg transition-all duration-300 ${dark ? 'bg-pink-600 text-white' : 'bg-white text-pink-600'}`}>
        <NailIcon size={20} className="animate-pulse" />
      </div>
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.5, 1, 0.5]
        }}
        transition={{ 
          repeat: Infinity, 
          duration: 3,
          ease: "easeInOut"
        }}
        className="absolute -top-1 -right-1 w-3 h-3 bg-pink-400 rounded-full blur-[2px]"
      />
    </motion.div>
    <span className={`text-2xl font-serif font-bold tracking-tight drop-shadow-md ${dark ? 'text-slate-900' : 'text-white'}`}>
      KOLKATA <span className="bg-gradient-to-r from-pink-500 to-rose-400 bg-clip-text text-transparent italic">HOME NAILS</span>
    </span>
  </div>
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Book Now', href: '#booking' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-white/80 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 flex justify-between items-center">
        <Logo dark={isScrolled} />

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`text-xs uppercase tracking-[0.2em] font-medium transition-all ${isScrolled ? 'text-slate-600 hover:text-pink-600' : 'text-white/80 hover:text-white'}`}
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button 
          className={`md:hidden p-2 transition-colors ${isScrolled ? 'text-slate-900' : 'text-white'}`}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-black/95 z-[60] flex flex-col items-center justify-center gap-8 p-8"
          >
            <button 
              className="absolute top-8 right-8 text-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X size={32} />
            </button>
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-2xl font-serif text-white/90 hover:text-pink-400 transition-colors"
              >
                {link.name}
              </a>
            ))}
            <div className="flex flex-col gap-4 w-full max-w-xs mt-8">
              <a href={CALL_LINK} className="flex items-center justify-center gap-3 py-4 border border-white/20 text-white rounded-full text-sm font-bold uppercase tracking-widest">
                <Phone size={18} /> Call
              </a>
              <a 
                href={WHATSAPP_LINK} 
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 py-4 bg-pink-600 text-white rounded-full text-sm font-bold uppercase tracking-widest"
              >
                <MessageCircle size={18} /> WhatsApp
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=2000&auto=format&fit=crop" 
          alt="Kolkata Home Nails" 
          className="w-full h-full object-cover scale-105 animate-slow-zoom"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
      </div>
      
      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <h1 className="text-4xl md:text-6xl font-serif font-medium text-white leading-[1.1] mb-8 drop-shadow-2xl tracking-tight">
            Professional Nail Art <br />
            <span className="italic">at Your Doorstep</span>
          </h1>
          <p className="text-lg md:text-xl text-white/70 mb-12 max-w-2xl mx-auto leading-relaxed font-light">
            Get salon-quality nail care at the comfort of your home. Expert nail artists, trendy designs, and hygienic service delivered to your doorstep in Kolkata.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <motion.a 
              href={WHATSAPP_LINK}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full sm:w-auto px-10 py-5 bg-pink-600/90 hover:bg-pink-600 text-white rounded-full font-bold uppercase tracking-widest text-xs transition-all shadow-2xl"
            >
              Book Appointment
            </motion.a>
            <motion.a 
              href="#services"
              whileHover={{ scale: 1.02, backgroundColor: "rgba(255,255,255,0.1)" }}
              whileTap={{ scale: 0.98 }}
              className="w-full sm:w-auto px-10 py-5 border border-white/30 text-white rounded-full font-bold uppercase tracking-widest text-xs backdrop-blur-sm transition-all"
            >
              View Services
            </motion.a>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4"
      >
        <span className="text-[10px] uppercase tracking-[0.5em] text-white/40 font-bold">Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-white/40 to-transparent" />
      </motion.div>
    </section>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-pink-600 uppercase tracking-[0.2em] mb-3">Our Expertise</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-6">Premium Services We Offer</h3>
          <p className="text-slate-500 max-w-2xl mx-auto">
            From classic manicures to intricate nail art, we provide a wide range of professional beauty services at your doorstep.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {SERVICES.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="group relative aspect-[4/5] rounded-3xl overflow-hidden shadow-md"
            >
              <img 
                src={service.image} 
                alt={service.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4 md:p-6">
                <div className="w-8 h-8 md:w-10 md:h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center text-white mb-3 group-hover:bg-pink-600 transition-colors">
                  {service.icon}
                </div>
                <h4 className="text-white font-bold text-sm md:text-lg leading-tight">{service.title}</h4>
                <p className="text-white/70 text-[10px] md:text-xs mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Gallery = () => {
  return (
    <section id="gallery" className="py-24 bg-pink-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-sm font-bold text-pink-600 uppercase tracking-[0.2em] mb-3">Portfolio</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-slate-900">Our Recent Work</h3>
          </div>
          <p className="text-slate-500 max-w-md">
            Take a look at some of our favorite designs and transformations created for our lovely clients in Kolkata.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
          {GALLERY.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03 }}
              className="relative aspect-square rounded-3xl overflow-hidden group shadow-lg"
            >
              <img 
                src={item.url} 
                alt={item.category} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-pink-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-white/70 text-xs font-bold uppercase tracking-widest mb-1">{item.category}</span>
                <h4 className="text-white font-bold text-lg">Premium Design</h4>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <motion.a 
            href={WHATSAPP_LINK}
            whileHover={{ scale: 1.05 }}
            className="inline-flex items-center gap-3 px-10 py-4 bg-white text-pink-600 border-2 border-pink-100 rounded-2xl font-bold shadow-lg hover:bg-pink-50 transition-all"
          >
            View More on WhatsApp <MessageCircle className="w-5 h-5" />
          </motion.a>
        </div>
      </div>
    </section>
  );
};

const WhyUs = () => {
  return (
    <section id="why-us" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm font-bold text-pink-600 uppercase tracking-[0.2em] mb-3">Excellence</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-8">Why Kolkata Home Nails?</h3>
            
            <div className="space-y-8">
              {REASONS.map((reason, index) => (
                <motion.div 
                  key={reason.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex gap-5"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-pink-50 rounded-2xl flex items-center justify-center">
                    {reason.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">{reason.title}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed">{reason.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <div className="relative">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative z-10 grid grid-cols-2 gap-4"
            >
              <div className="space-y-4 pt-12">
                <img src="https://images.unsplash.com/photo-1519415387722-a1c3bbef716c?q=80&w=600" className="rounded-3xl shadow-lg aspect-[3/4] object-cover" alt="Service" />
                <img src="https://images.unsplash.com/photo-1583001931096-959e9a1a6223?q=80&w=600" className="rounded-3xl shadow-lg aspect-square object-cover" alt="Service" />
              </div>
              <div className="space-y-4">
                <img src="https://images.unsplash.com/photo-1607779097040-26e80aa78e66?q=80&w=600" className="rounded-3xl shadow-lg aspect-square object-cover" alt="Service" />
                <img src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=600" className="rounded-3xl shadow-lg aspect-[3/4] object-cover" alt="Service" />
              </div>
            </motion.div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-pink-100/50 rounded-full blur-3xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
};

const Booking = () => {
  return (
    <section id="booking" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-slate-900 rounded-[3rem] overflow-hidden p-8 md:p-16 text-center">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-pink-500 via-transparent to-transparent" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative z-10"
          >
            <h2 className="text-pink-400 font-bold uppercase tracking-widest mb-4">Instant Appointment</h2>
            <h3 className="text-4xl md:text-6xl font-serif font-bold text-white mb-8 leading-tight">
              Ready for Your <span className="text-pink-500 italic">Nail Transformation?</span>
            </h3>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto mb-12">
              Book your home service now and get professional nail art at your convenience. We are available across Kolkata.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <motion.a 
                href={CALL_LINK}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full sm:w-auto flex items-center justify-center gap-3 px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-lg shadow-2xl"
              >
                <Phone className="w-6 h-6" /> Call: {CONTACT_NUMBER}
              </motion.a>
              <motion.a 
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full sm:w-auto flex items-center justify-center gap-3 px-10 py-5 bg-pink-600 text-white rounded-2xl font-bold text-lg shadow-2xl shadow-pink-900/20"
              >
                <MessageCircle className="w-6 h-6" /> WhatsApp Booking
              </motion.a>
            </div>
            
            <div className="mt-12 flex flex-wrap justify-center gap-8 text-slate-400 text-sm font-medium">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-pink-500" /> Available 7 Days a Week
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-pink-500" /> Service All Over Kolkata
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-pink-500" /> 100% Safe & Hygienic
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-50 pt-20 pb-10 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2">
            <Logo className="mb-6" dark={true} />
            <p className="text-slate-500 max-w-sm leading-relaxed mb-8">
              Get salon-quality nail care at the comfort of your home. Expert nail artists, trendy designs, and hygienic service delivered to your doorstep in Kolkata.
            </p>
            <div className="flex gap-4">
              {[1,2,3].map(i => (
                <div key={i} className="w-10 h-10 bg-white border border-slate-200 rounded-xl flex items-center justify-center text-slate-600 hover:text-pink-600 hover:border-pink-200 transition-colors cursor-pointer">
                  <Heart className="w-5 h-5" />
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-slate-900 mb-6">Quick Links</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#" className="hover:text-pink-600 transition-colors">Home</a></li>
              <li><a href="#services" className="hover:text-pink-600 transition-colors">Services</a></li>
              <li><a href="#gallery" className="hover:text-pink-600 transition-colors">Gallery</a></li>
              <li><a href="#why-us" className="hover:text-pink-600 transition-colors">Why Choose Us</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-slate-900 mb-6">Contact Us</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-pink-500" /> {CONTACT_NUMBER}
              </li>
              <li className="flex items-center gap-3">
                <MessageCircle className="w-4 h-4 text-pink-500" /> WhatsApp Available
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-pink-500" /> Kolkata, West Bengal
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-xs font-medium">
          <p>© {new Date().getFullYear()} Kolkata Home Nails. All rights reserved.</p>
          <p>Service Area: Kolkata & Surrounding Regions</p>
        </div>
      </div>
    </footer>
  );
};

const FloatingButtons = () => {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
      <motion.a 
        href={CALL_LINK}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="w-14 h-14 bg-slate-900 text-white rounded-full shadow-2xl flex items-center justify-center"
      >
        <Phone className="w-6 h-6" />
      </motion.a>
      <motion.a 
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="w-14 h-14 bg-pink-600 text-white rounded-full shadow-2xl flex items-center justify-center"
      >
        <MessageCircle className="w-6 h-6" />
      </motion.a>
    </div>
  );
};

export default function App() {
  return (
    <div className="relative">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <Gallery />
        <WhyUs />
        <Booking />
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
